#include <windows.h>
#include <gl/gl.h>
#include "GameCamera.h"
#include <math.h>

struct SCamera camera={0,0,-6, 0,0};

void CamerAutoMouse(int centerX, int centerY, float speed){
    POINT cur;
    POINT base = {centerX,centerY};
    GetCursorPos(&cur);
    CameraTorsion( (base.y - cur.y)/5,(base.x - cur.x)/5);
    SetCursorPos(base.x,base.y);
}

void CameraApply() {
    glRotatef(-camera.XTor,1,0,0);
    glRotatef(camera.ZTor,0,0,1);
    glTranslatef(-camera.x, camera.y, -camera.z);
}

void CameraTorsion(float xTilt, float zTilt){
    camera.ZTor+=zTilt;
    if( camera.ZTor<0) camera.ZTor +=360;
    if( camera.ZTor>360) camera.ZTor -=360;
    camera.XTor+=xTilt;
    if( camera.XTor<0) camera.XTor =0;
    if( camera.XTor<180) camera.XTor =180;
}

void CameraDirectional(int forwardMove, int rightMove, float speed){

    float Tilt= -camera.ZTor/180*M_PI;

    if (forwardMove>0)
            Tilt+=rightMove>0 ? M_PI_4 :(rightMove<0 ? -M_PI_4 :0);
    if (forwardMove<0)
            Tilt+=M_PI + (rightMove>0 ? -M_PI_4 :(rightMove<0 ? M_PI_4 :0));
    if (forwardMove==0) {
        Tilt +=rightMove > 0? M_PI_2 : -M_PI_2;
        if (rightMove==0) speed=0;
    }
    if (speed!=0) {
        camera.x+= sin(Tilt)*speed;
        camera.y+= cos(Tilt)*speed;
    }
}
